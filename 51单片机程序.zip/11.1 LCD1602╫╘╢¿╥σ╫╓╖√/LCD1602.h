#ifndef __LCD1602_H__
#define __LCD1602_H__

//void LCD_WriteCommand(unsigned char Command);
//void LCD_WriteData(unsigned char Date);
void LCD_Init(void);
//void LCD_ShowChar(unsigned char Line,unsigned char Column,unsigned char Char);
//void LCD_ShowString(unsigned char Line,unsigned char Column,unsigned char String[]);
//void LCD_ShowNumber(unsigned char Line,unsigned char Column,unsigned int Number,unsigned char Length);
//void LCD_ShowSignedNumber(unsigned char Line,unsigned char Column,int Number,unsigned char Length);
//void LCD_ShowHexNumber(unsigned char Line,unsigned char Column,unsigned int Number,unsigned char Length);
//void LCD_ShowBinNumber(unsigned char Line,unsigned char Column,unsigned int Number,unsigned char Length);
//void LCD_WriteCGRAM(unsigned char Number,unsigned char String[]);
//void LCD_ShowCGRAM(unsigned char Line,unsigned char Column,unsigned char Number);
void LCD_WritePicture(unsigned char Picture[][8]);
void LCD_ShowPicture(unsigned char Line,unsigned char Column);

#endif 