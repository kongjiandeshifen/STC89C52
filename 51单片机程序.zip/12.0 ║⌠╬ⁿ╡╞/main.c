#include <REGX52.H>


sbit LED=P2^0;

void LED_Delay(unsigned int t);

void main()
{
	unsigned char Time,i;
	while(1)
	{
		for(Time=0;Time<100;Time++)
		{
			for(i=0;i<20;i++)
			{
				LED=0;
				LED_Delay(Time);
				LED=1;
				LED_Delay(100-Time);
			}
		}
		
		for(Time=100;Time>0;Time--)
		{
			for(i=0;i<20;i++)
			{
				LED=0;
				LED_Delay(Time);
				LED=1;
				LED_Delay(100-Time);
			}
		}
	}
}

void LED_Delay(unsigned int t)
{
	while(t--);
}