#include<REGX52.H>
#include "Delay.h"
#include "Nixie.h"

void main()
{
	while(1)
	{
		NixieShow(1,1);
		NixieShow(2,2);
		NixieShow(3,3);
		NixieShow(4,4);
		NixieShow(5,5);
		NixieShow(6,6);
		NixieShow(7,7);
		NixieShow(8,8);
	}
}