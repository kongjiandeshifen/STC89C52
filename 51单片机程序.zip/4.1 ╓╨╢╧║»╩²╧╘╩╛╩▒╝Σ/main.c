#include <REGX52.H>
#include "Timer0.h"
#include "Key.h"
#include "LCD1602.h"
unsigned char KeyNum;
unsigned char Sec,Min,Hour;

void main()
{
	Timer0_Init();
	LCD_Init();
	while(1)
	{
		LCD_ShowString(1,5,"My Clock");
		LCD_ShowString(2,7,":");
		LCD_ShowString(2,10,":");
		LCD_ShowNum(2,5,Hour,2);
		LCD_ShowNum(2,8,Min,2);
		LCD_ShowNum(2,11,Sec,2);
		
		/*KeyNum=Key();
		if(KeyNum)
		{
			if(KeyNum==1){P2_1=~P2_1;}
			if(KeyNum==2){P2_2=~P2_2;}
			if(KeyNum==3){P2_3=~P2_3;}
			if(KeyNum==4){P2_4=~P2_4;}
		}
		*/
	}
}


void Timer0_Rountine() interrupt 1 
{
		static unsigned int T0Count;
		TL0 = 0x66;		
		TH0 = 0xFC;
		T0Count++;
		if(T0Count>=1000)
		{
			T0Count=0;
			Sec++;
			if(Sec>=60)
			{
				Sec=0;
				Min++;
				if(Min>=60)
				{
						Min=0;
						Hour++;
					if(Hour>=24)
					{
						Hour=0;
					}
				}
			}
	  }
}
