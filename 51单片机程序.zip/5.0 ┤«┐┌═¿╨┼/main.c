#include <REGX52.H>
#include "Delay.h"
#include "Uart.h"

void main()
{
	Uart_Init();
	while(1)
	{
		Uart_SendByte(0x01);
		Delay(1000);
	}
}
