#include <REGX52.H>
#include "Delay.h"
#include "Timer0.h"

#define SPEED 	100

#define p0		0
#define L1		1
#define L1_		2
#define L2		3
#define L2_		4
#define L3		5
#define L4		6
#define L4_		7
#define L5		8
#define L5_		9
#define L6		10
#define L6_		11
#define L7		12
#define M1		13
#define M1_		14
#define M2		15
#define M2_		16
#define M3		17
#define M4		18
#define M4_		19
#define M5		20
#define M5_		21
#define M6		22
#define M6_		23
#define M7		24
#define H1		25
#define H1_		26
#define H2		27
#define H2_		28
#define H3		29
#define H4		30
#define H4_		31
#define H5		32
#define H5_		33
#define H6		34
#define H6_		35
#define H7		36

sbit Buzzer=P1^5;

unsigned int FreTable[]=
{
	0,
	63778,63873,63968,63988,64140,64215,64291,64369,64360,64489,64547,64607,
	64655,64704,64751,64795,64837,64876,64913,64948,64981,65036,65042,65070,
	65095,65120,65143,65166,65187,65206,65224,65242,65259,65274,65289,65303
};
//����[0]Ϊ��ֹ��0
//ʱ��
// 1/16  1/8 1/4 1/2  1/1
//   1    2   4   8    16

unsigned char code Music[]=
{
	H3,8,
	H5,8,
	H5,12,
	H6,4,
	H5,8,
	H3,8,
	H1,8,
	H1,4,
	H2,4,
	
	H3,8,
	H3,8,
	H2,8,
	H1,8,
	H2,16,
	p0,16,
	
	H3,8,
	H5,8,
	H5,12,
	H6,4,
	H5,8,
	H3,8,
	H1,8,
	H1,4,
	H2,4,
	
	H3,8,
	H3,8,
	H2,8,
	H2,8,
	H1,16,
	p0,16,
	
	H4,16,
	H4,16,
	H4,8,
	H6,24,
	
	H5,16,
	H5,8,
	H3,8,
	H2,16,
	p0,16,
	
	H3,8,
	H5,8,
	H5,12,
	H6,4,
	H5,8,
	H3,8,
	H1,8,
	H1,4,
	H2,4,
	
	H3,8,
	H3,8,
	H2,8,
	H2,8,
	H1,16,
	p0,16,
	
	0xFF
};

unsigned char FreqSelect,MusicSelect;

void main()
{
	Timer0Init();
	while(1)
	{
		if(Music[MusicSelect]!=0xFF)
		{
		FreqSelect=Music[MusicSelect];
		MusicSelect++;
		Delay(SPEED/4*Music[MusicSelect]);
		MusicSelect++;
		TR0=0;
		Delay(10);
		TR0=1;
		}
		else
		{
			TR0=0;
			while(1);
		}
	}
}

void Timer0_Rountine() interrupt 1 
{	
	if(FreTable[FreqSelect])
	{
		TL0 =FreTable[FreqSelect]%256;		
		TH0 =FreTable[FreqSelect]/256;
		Buzzer=!Buzzer;
	}
}