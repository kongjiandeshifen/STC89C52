#include <REGX52.H>
#include "LCD1602.h"

sbit Tring=P1^0;
sbit Echo=P1^1;
sbit LED1=P2^0;
sbit LED2=P2^1;
sbit LED3=P2^2;

typedef unsigned int u16;

u16 time;
u16 s;

void delay(u16 i)
{
	while(i--);
}

void main()
{
	LCD_Init();
	while(1)
	{
		TMOD &= 0x0;		
		TMOD |= 0x01;
		TL0 = 0x0;		 
		TH0 = 0x0;		
			
		Tring=1;
		delay(2);
		Tring=0;
		while(!Echo);
		TR0=1;
		while(Echo);
		TR0=0;
		time=TH0*256+TL0;
		s=(time*1.7)/100;
		TH0=0;
		TL0=0;
		
		LCD_ShowNum(1,1,s,5);
		if(s>=50)
		{
			LED1=0;
			LED2=0;
			LED3=0;
		}
		else if(s<50 && s>=25)
		{
			LED1=1;
			LED2=0;
			LED3=0;
		}
		else if(s<25)
		{
			LED1=1;
			LED2=1;
			LED3=0;
		}
		delay(65535);
	}
}