#include <REGX52.H>
#include "Timer0.h"
#include "Key.h"
#include "LCD1602.h"

unsigned char KeyNum;
unsigned char KeyMode=0,Mode=0;
unsigned int Year=2021,Sec=0,Min=30,Hour=23,Month=5,Day=12,WeekDay=2,flag=0;
unsigned char code Week[7][5]={"Mon ","Tues"," Wed ","Thur"," Fri "," Sat "," Sun "};
unsigned char code MonthDay[2][13]={0,31,28,31,30,31,30,31,31,30,31,30,31,
									0,31,29,31,30,31,30,31,31,30,31,30,31,};

void main()
{
	Timer0_Init();
	LCD_Init();
	while(1)
	{
		KeyNum=Key();
		if(KeyNum)
		{
			if(KeyNum==1)
			{
				KeyMode=~KeyMode;
				if(KeyMode!=0&&Mode==0){LCD_ShowString(2,11,"year");}
			}
			
			if(KeyNum==2 && KeyMode!=0 )
			{
				Mode++;
				if(Mode>=7){Mode=0;}
				if(KeyMode!=0&&Mode==0){LCD_ShowString(2,11,"year");}
				if(KeyMode!=0&&Mode==1){LCD_ShowString(2,11," mon");}
				if(KeyMode!=0&&Mode==2){LCD_ShowString(2,11," day");}
				if(KeyMode!=0&&Mode==3){LCD_ShowString(2,11,"week");}
				if(KeyMode!=0&&Mode==4){LCD_ShowString(2,11,"hour");}
				if(KeyMode!=0&&Mode==5){LCD_ShowString(2,11," min");}
				if(KeyMode!=0&&Mode==6){LCD_ShowString(2,11," sec");}
			}
						
			if(KeyNum==3 && KeyMode!=0)
			{
				if(KeyMode!=0&&Mode==0){if(Year<=0){Year=2000;}else{Year--;}                    LCD_ShowString(2,11,"year");}
				if(KeyMode!=01&&Mode==1){if(Month<=1){Month=12;}else{Month--;}                  LCD_ShowString(2,11," mon");}
				if(KeyMode!=0&&Mode==2){if(Day<=1){Day=MonthDay[flag][Month];}else{Day--;}      LCD_ShowString(2,11," day");}
				if(KeyMode!=0&&Mode==3){if(WeekDay<=0){WeekDay=6;}else{WeekDay--;}              LCD_ShowString(2,11,"week");}
				if(KeyMode!=0&&Mode==4){if(Hour<=0){Hour=23;}else{Hour--;}                      LCD_ShowString(2,11,"hour");}
				if(KeyMode!=0&&Mode==5){if(Min<=0){Min=59;}else(Min--);                         LCD_ShowString(2,11," min");}
				if(KeyMode!=0&&Mode==6){Sec=0;                                                  LCD_ShowString(2,11," sec");}
			}
						
			if(KeyNum==4 && KeyMode!=0)
			{
				if(KeyMode!=0&&Mode==0){Year++;                                                 LCD_ShowString(2,11,"year");}
				if(KeyMode!=0&&Mode==1){if(Month>=12){Month=1;}else{Month++;}                   LCD_ShowString(2,11," mon");}
				if(KeyMode!=0&&Mode==2){if(Day>=MonthDay[flag][Month]){Day=1;}else{Day++;}      LCD_ShowString(2,11," day");}
				if(KeyMode!=0&&Mode==3){if(WeekDay>=6){WeekDay=0;}else{WeekDay++;}              LCD_ShowString(2,11,"week");}
				if(KeyMode!=0&&Mode==4){if(Hour>=23){Hour=0;}else{Hour++;}                      LCD_ShowString(2,11,"hour");}
				if(KeyMode!=0&&Mode==5){if(Min>=59){Min=0;}else{Min++;}                         LCD_ShowString(2,11," min");}
				if(KeyMode!=0&&Mode==6){Sec=0;                                                  LCD_ShowString(2,11," sec");}
			}
						
			if(KeyMode!=0){LCD_ShowChar(2,16,'S');}
			else{LCD_ShowString(2,11,"      ");}
		}
		LCD_ShowNum(1,1,Year,4);
		LCD_ShowString(1,5,"-");
		
		LCD_ShowNum(1,6,Month,2);
		LCD_ShowString(1,8,"-");
		
		LCD_ShowNum(1,9,Day,2);
		LCD_ShowString(1,13,Week[WeekDay]);
		LCD_ShowNum(2,1,Hour,2);
		LCD_ShowString(2,3,":");
		LCD_ShowNum(2,4,Min,2);
		LCD_ShowString(2,6,":");
		LCD_ShowNum(2,7,Sec,2);
	}
}


void Timer0_Rountine() interrupt 1 //计数器到溢出进入中断
{
		static unsigned int T0Count;
		TL0 = 0x66;		//重新赋初值
		TH0 = 0xFC;
		T0Count++;
		if(T0Count>=1000)
		{
			T0Count=0;
			Sec++;
			if(Sec>=60)
			{
				Sec=0;
				Min++;
				if(Min>=60)
				{
						Min=0;
						Hour++;
					if(Hour>=24)
					{
						Hour=0;
						Day++;
						WeekDay++;
						if(WeekDay>=7)
						{
							WeekDay=0;
						}
						if(Day>=MonthDay[flag][Month])
						{
							Day=1;
							Month++;
							if(Month>=13)
							{
								Month=1;
								Year++;
								if(Year%4==0 && Year%100!=0 || Year%400==0){flag=1;}
			          else{flag=0;}
							}
						}	
					}
				}
			}
	  }
}