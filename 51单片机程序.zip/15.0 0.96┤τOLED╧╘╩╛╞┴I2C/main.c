#include <REGX52.H>
#include "OLED.h"
#include "Delay.h"
#include "Character.h"


void main()
{
	unsigned char i='A';
	OLED_Init();
	
	//OLED_ClearScreen();
	
	OLED_ShowCharacter(3,0,Character[0]);
	OLED_ShowCharacter(3,16,Character[1]);
	OLED_ShowCharacter(3,32,Character[2]);
	OLED_ShowCharacter(3,48,Character[3]);
	OLED_ShowCharacter(3,64,Character[4]);
	OLED_ShowCharacter(3,80,Character[5]);
	OLED_ShowCharacter(3,96,Character[6]);
	OLED_ShowCharacter(3,112,Character[7]);
	
	OLED_ShowAscii(5,0,Ascii['i'-0x21]);
	OLED_ShowAscii(5,8,Ascii[' '+0x3E]);
	OLED_ShowAscii(5,16,Ascii['l'-0x21]);
	OLED_ShowAscii(5,24,Ascii['o'-0x21]);
	OLED_ShowAscii(5,32,Ascii['v'-0x21]);
	OLED_ShowAscii(5,40,Ascii['e'-0x21]);
	OLED_ShowAscii(5,48,Ascii[' '+0x3E]);
	OLED_ShowAscii(5,56,Ascii['y'-0x21]);
	OLED_ShowAscii(5,64,Ascii['o'-0x21]);
	OLED_ShowAscii(5,72,Ascii['u'-0x21]);
	OLED_ShowAscii(5,81,Ascii['!'-0x21]);
	
	//OLED_ShowPicture(Picture[0]);
	//OLED_ShowPicture(Picture[1]);
	//OLED_ShowPicture(Picture[2]);
	
	while(1)
	{
	}
}