#ifndef __OLED_H__
#define __OLED_H__

unsigned char OLED_SendCommand(unsigned char Command);
unsigned char OLED_SendData(unsigned char Data);
void OLED_Init(void);
void OLED_SetPosition(unsigned char Page,unsigned char Column);
void OLED_ClearScreen(void);
void OLED_ShowAscii(unsigned char Page,unsigned char Column,unsigned char String[]);
void OLED_ShowCharacter(unsigned char Page,unsigned char Column,unsigned char String[]);
void OLED_ShowPicture(unsigned char String[]);


#endif 