#ifndef __CHARACTER_H__
#define __CHARACTER_H__

extern unsigned char code Ascii[][8];
extern unsigned char code Character[][32];
extern unsigned char code Picture[][1024];

#endif 