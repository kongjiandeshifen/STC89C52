#include <REGX52.H>
#include "Timer0.h"
#include "Key.h"
unsigned char KeyNum;

void main()
{
	Timer0_Init();
	while(1)
	{
		KeyNum=Key();
		if(KeyNum)
		{
			if(KeyNum==1){P2_1=~P2_1;}
			if(KeyNum==2){P2_2=~P2_2;}
			if(KeyNum==3){P2_3=~P2_3;}
			if(KeyNum==4){P2_4=~P2_4;}
		}
	}
}


void Timer0_Rountine() interrupt 1 //计数器到溢出进入中断
{
		static unsigned int T0Count;
		TL0 = 0x66;		//重新赋初值
		TH0 = 0xFC;
		T0Count++;
		if(T0Count>=1000)
		{
			T0Count=0;
			P2_7=~P2_7;
	  }
}