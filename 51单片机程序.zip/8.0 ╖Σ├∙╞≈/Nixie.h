#ifndef __NIXIE_H__
#define __NIXIE_H__

extern unsigned char Number[];
	
void Nixie_ShowNum(int location,int num);
	
#endif