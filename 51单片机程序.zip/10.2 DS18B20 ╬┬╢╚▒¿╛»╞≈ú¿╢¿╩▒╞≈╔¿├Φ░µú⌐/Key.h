#ifndef   __KEY_H__
#define   __KEY_H__

unsigned char Key();
void Key_Loop(void);
unsigned char Key_GetState();

#endif