#include <REGX52.H>
#include "Uart.h"
//#include "LCD1602.h"

sbit IN1=P0^3;
sbit IN2=P0^2;
sbit IN3=P0^1;
sbit IN4=P0^0;

#define BIT0 0x01
#define BIT1 0x02
#define BIT2 0x04
#define BIT3 0x08
#define STOP 0x00

void Control_Init(void);
void Control_Byte(void);
void Control_L298N(void);

unsigned char Byte=0x00;
unsigned char ControlByte=0x00;

void main()
{
	Uart_Init();
	//LCD_Init();
	//Control_Init();
	
	//LCD_ShowString(1,1,"Byte:");
	//LCD_ShowString(1,9,"CByte:");
	
	
	while(1)
	{
		/*
		LCD_ShowChar(1,6,Byte);
		LCD_ShowHexNum(1,15,ControlByte,2);
		LCD_ShowNum(2,3,IN1,2);
		LCD_ShowNum(2,7,IN2,2);
		LCD_ShowNum(2,11,IN3,2);
		LCD_ShowNum(2,15,IN4,2);
		*/
		Control_Byte();
		Control_L298N();
		
		
	}
}

void Uart_Routine() interrupt 4
{
	 if(RI==1)
	 {
		 Byte=SBUF;
		 RI=0;
	 }
}

void Control_Init(void)
{
	IN1=0;
	IN2=0;
	IN3=0;
	IN4=0;
}

void Control_Byte(void)
{
	
		if(Byte=='G')//ǰ��
		{
			ControlByte |=BIT3;
			ControlByte &=~BIT2;
			ControlByte &=~(BIT0+BIT1);
		}
		else if(Byte=='K')//����
		{
			ControlByte |=BIT2;
			ControlByte &=~BIT3;
			ControlByte &=~(BIT0+BIT1);
		}
		else if(Byte=='H')//��ת
		{
			ControlByte |=BIT1;
			ControlByte &=~BIT0;
		}
		else if(Byte=='J')//��ת
		{
			ControlByte |=BIT0;
			ControlByte &=~BIT1;
		}
		else if(Byte=='I')//ֹͣ
		{
			ControlByte = STOP;
		}
		else
		{
			ControlByte = STOP;
		}
	
}

void Control_L298N(void)
{
	if(ControlByte==0x08)//ǰ��
	{
		IN1=0;
		IN2=1;
		IN3=1;
		IN4=0;
		
	}
	if(ControlByte==0x04)//����
	{
		IN1=1;
		IN2=0;
		IN3=0;
		IN4=1;
	}
	if(ControlByte==0x0A)//ǰ��
	{
		IN1=0;
		IN2=0;
		IN3=1;
		IN4=0;
	}
	if(ControlByte==0x02)//��
	{
		IN1=1;
		IN2=0;
		IN3=1;
		IN4=0;
	}
	if(ControlByte==0x01)//��
	{
		IN1=0;
		IN2=1;
		IN3=0;
		IN4=1;
	}
	if(ControlByte==0x09)//ǰ��
	{
		IN1=0;
		IN2=1;
		IN3=0;
		IN4=0;
	}
	if(ControlByte==0x06)//����
	{
		IN1=0;
		IN2=0;
		IN3=0;
		IN4=1;
	}
	if(ControlByte==0x05)//����
	{
		IN1=1;
		IN2=0;
		IN3=0;
		IN4=0;
	}
	if(ControlByte==STOP)//ֹͣ
	{
		IN1=0;
		IN2=0;
		IN3=0;
		IN4=0;
	}
}