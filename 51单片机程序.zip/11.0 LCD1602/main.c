#include <REGX52.H>
#include "LCD1602.h"
#include "Delay.h"

void main()
{
	LCD_Init();
	/*
	LCD_WriteCommand(0x40);
	LCD_WriteData(0x1F);
	
	LCD_WriteCommand(0x41);
	LCD_WriteData(0x08);
	
	LCD_WriteCommand(0x42);
	LCD_WriteData(0x08);
	
	LCD_WriteCommand(0x43);
	LCD_WriteData(0x1E);
	
	LCD_WriteCommand(0x44);
	LCD_WriteData(0x0A);
	
	LCD_WriteCommand(0x45);
	LCD_WriteData(0x0A);
	
	LCD_WriteCommand(0x46);
	LCD_WriteData(0x0A);
	
	LCD_WriteCommand(0x47);
	LCD_WriteData(0x1F);
	
	LCD_WriteCommand(0x83);
	LCD_WriteData(0x00);
	*/
	LCD_ShowChar(1,1,'/');
	LCD_ShowString(1,3,"Hello");
	LCD_ShowNum(1,9,66,2);
	LCD_ShowSignedNum(1,12,-88,2);
	LCD_ShowHexNum(2,1,0xA5,2);
	LCD_ShowBinNum(2,4,0xA5,8);
	LCD_ShowChar(2,13,0xB4);
	LCD_ShowChar(2,13,0xEF);
	LCD_ShowChar(2,14,0xFF);
	LCD_ShowString(1,16,"Welcome to China");
	while(1)
	{
		LCD_WriteCommand(0x18);
		Delay(1000);
	}
}