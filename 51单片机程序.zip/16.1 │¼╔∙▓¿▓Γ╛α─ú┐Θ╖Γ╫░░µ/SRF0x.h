#ifndef __SRF0X_H__
#define __SRF0X_H__

void SFR0x_Init();
unsigned int SFR0x_Distance();

#endif 