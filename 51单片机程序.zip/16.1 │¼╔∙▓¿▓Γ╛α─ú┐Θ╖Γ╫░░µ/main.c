#include <REGX52.H>
#include "LCD1602.h"
#include "SRF0x.h"

sbit Tring=P1^0;
sbit Echo=P1^1;

unsigned int distance;

void main()
{
	LCD_Init();
	SFR0x_Init();
	while(1)
	{
		distance=SFR0x_Distance();
		LCD_ShowNum(1,1,distance,5);
		LCD_ShowString(1,6,"cm");
	}
}