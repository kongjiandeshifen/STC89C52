#ifndef   __UART_H__
#define  	__UART_H__

void Uart_Init(void);
void Uart_SendByte(unsigned char Byte);

#endif