#include <REGX52.H>
#include "Delay.h"
#include "LCD1602.h"
#include "Uart.h"

unsigned char Byte;

void main()
{
	Uart_Init();
	LCD_Init();
	while(1)
	{
		if(Byte=='A')
		{
			Uart_SendByte(0x49);
			Delay(500);
			Uart_SendByte(0x20);
			Delay(250);
			Uart_SendByte(0x4C);
			Delay(500);
			Uart_SendByte(0x4F);
			Delay(500);
			Uart_SendByte(0x56);
			Delay(500);
			Uart_SendByte(0x45);
			Delay(500);
			Uart_SendByte(0x20);
			Delay(250);
			Uart_SendByte(0x59);
			Delay(500);
			Uart_SendByte(0x4F);
			Delay(500);
			Uart_SendByte(0x55);
			Delay(500);
			Uart_SendByte(0x20);
			Delay(1000);
			Byte='0';
		}
	}
}

void Uart_Routine() interrupt 4
{
	 if(RI==1)
	 {
		 Byte=SBUF;
		 LCD_ShowChar(1,1,Byte);
		 RI=0;
	 }
}