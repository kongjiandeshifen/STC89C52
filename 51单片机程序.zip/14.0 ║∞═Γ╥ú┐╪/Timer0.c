#include <REGX52.H>

/*
 * @brief  定时器计时
 * @param  无
 * @retval 无
*/
void Timer0_Init(void)		
{
	TMOD &= 0xF0;		//设置定时器模式
	TMOD |= 0x01;
	TL0 = 0x0;		//设置高位   
	TH0 = 0x0;		//设置定时初值
	TF0 = 0;		//清除TF0标志
	TR0 = 0;		//定时器0不计时
}

/*
 * @brief  设置定时器初值
 * @param  定时器初值(0-65535)
 * @retval 无
*/
void Timer0_SetCounter(unsigned int Value)
{
	TH0 = Value/256;
	TL0 = Value%256;
}

/*
 * @brief  返回定时器最终值
 * @param  无
 * @retval 最终值(0-65535)
*/
unsigned int Timer0_GetCounter(void)
{
	return (TH0<<8)|TL0;
}

/*
 * @brief 定时器运行
 * @param 1运行,0不运行
 * @retval 无
*/
void Timer0_Run(unsigned char Flag)
{
	TR0=Flag;
}



