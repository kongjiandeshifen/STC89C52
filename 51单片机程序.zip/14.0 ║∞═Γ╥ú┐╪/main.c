#include <REGX52.H>
#include "Delay.h"
#include "LCD1602.h"
#include "IR.h"

unsigned char Address;
unsigned char Command;
unsigned char Num;

void main()
{
	LCD_Init();
	LCD_ShowString(1,1,"ADDR:");
	LCD_ShowString(2,1," CMD:");
	LCD_ShowString(1,10,"NUM:");
	IR_Init();
	while(1)
	{
		if(IR_GetDataFlag() || IR_GetRepeatFlag())
		{
			Address=IR_GetAddress();
			Command=IR_GetCommand();
			
			LCD_ShowHexNum(1,6,Address,2);
			LCD_ShowHexNum(2,6,Command,2);
			
			if(Command==IR_VOL_MINUS){Num--;}
			if(Command==IR_VOL_ADD){Num++;}
			LCD_ShowNum(1,14,Num,3);
		}
	}
}

