#ifndef __INT0_H__
#define __INT0_H__

void Int0_Init(void);

#endif 