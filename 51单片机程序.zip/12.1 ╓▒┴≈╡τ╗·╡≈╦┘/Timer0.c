#include <REGX52.H>


void Timer0Init(void)		//100微秒@11.0592MHz
{
	TMOD &= 0xF0;		//设置定时器模式
	TMOD |= 0x01;
	TL0 = 0xA4;		//设置高位   
	TH0 = 0xFF;		//设置定时初值
	TF0 = 0;		//清除TF0标志
	TR0 = 1;		//定时器0开始计时
	//配置中断接线
	ET0=1;
	EA=1;
	PT0=0;
}

/*
 * @brief 一毫秒模板
 * @param
 * @retval
*/
/*
void Timer0_Rountine() interrupt 1 //计数器到溢出进入中断
{
		static unsigned int T0Count;
		TL0 = 0xA4;		//重新赋初值
		TH0 = 0xFF;
		T0Count++;
		if(T0Count>=1000)
		{
			T0Count=0;
			
	  }
}
*/


