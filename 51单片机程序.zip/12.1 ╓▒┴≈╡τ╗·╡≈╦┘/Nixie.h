#ifndef __NIXIE_H__
#define __NIXIE_H__

extern unsigned char Number[];
	
void NixieShow(int location,int num);
	
#endif