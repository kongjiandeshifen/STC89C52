#include <REGX52.H>

sbit LED=P2^1;

int i=1300;

void main()
{
	while(1)
	{
		LED = 0;
		while(i--);
		LED = 1;
		while(i--);
	}
}