#include <REGX52.H>
#include "Delay.h"
#include "Key.h"
#include "Timer0.h"
#include "Nixie.h"

sbit SteeringEngine=P1^0;

unsigned char Counter,Compare,KeyNum,Angle;

void main()
{
	Timer0Init();
	SteeringEngine=0;
	while(1)
	{
		KeyNum=Key();
		if(KeyNum==1)
		{
			Angle++;
			Angle%=5;
			if(Angle==0){Compare=0;}
			if(Angle==1){Compare=1;}
			if(Angle==2){Compare=2;}
			if(Angle==3){Compare=3;}
			if(Angle==4){Compare=4;}
			
		 }
		NixieShow(1,Angle);
	}
}

void Timer0_Rountine() interrupt 1 //计数器到溢出进入中断
{
	
		TL0 = 0x33;		//重新赋初值
		TH0 = 0xFE;
		Counter++;
		Counter %= 20;
		if(Counter<Compare)
		{
			SteeringEngine=1;
		}
		else
		{
			 SteeringEngine=0;
		}
}