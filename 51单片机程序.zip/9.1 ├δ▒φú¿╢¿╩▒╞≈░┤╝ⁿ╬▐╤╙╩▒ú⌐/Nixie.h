#ifndef __NIXIE_H__
#define __NIXIE_H__

extern unsigned char Number[];
	
void Nixie_Show(unsigned char location,num);
void Nixie_Loop(void);
void Nixie_SetBuf(unsigned char location,num);
	
#endif