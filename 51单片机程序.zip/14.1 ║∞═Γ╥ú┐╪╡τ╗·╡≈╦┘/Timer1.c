#include <REGX52.H>

/*
 * @brief  定时器1初始化
 * @param  无
 * @retval 无
*/
void Timer1_Init(void)		//100微秒@11.0592MHz
{
	TMOD &= 0x0F;		//设置定时器模式
	TMOD |= 0x10;
	TL1 = 0xA4;		//设置高位   
	TH1 = 0xFF;		//设置定时初值
	TF1 = 0;		//清除TF0标志
	TR1 = 1;		//定时器0开始计时
	//配置中断接线
	ET1=1;
	EA=1;
	PT1=0;
}

/*
 * @brief 一毫秒模板
 * @param
 * @retval
*/
/*
void Timer1_Rountine() interrupt 3 //计数器到溢出进入中断
{
		static unsigned int T0Count;
		TL1 = 0xA4;		//重新赋初值
		TH1 = 0xFF;
		T0Count++;
		if(T0Count>=1000)
		{
			T0Count=0;
			
	  }
}
*/


