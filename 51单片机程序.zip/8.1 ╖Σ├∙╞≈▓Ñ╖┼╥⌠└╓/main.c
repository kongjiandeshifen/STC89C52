#include <REGX52.H>
#include "Delay.h"
#include "Timer0.h"

#define SPEED 250

sbit Buzzer=P1^5;

unsigned int FreTable[]=
{
	0,
	63778,63873,63968,63988,64140,64215,64291,64369,64360,64489,64547,64607,
	64655,64704,64751,64795,64837,64876,64913,64948,64981,65036,65042,65070,
	65095,65120,65143,65166,65187,65206,65224,65242,65259,65274,65289,65303
};
//����[0]Ϊ��ֹ��0
//����
// 1   2   3   4   5   6   7   8   9  10   11   12
// 1   1#  2   2#  3   4   4#  5   5#  6   6#    7
//����
// 13  14  15  16  17  18  19  20  21  22  23  24
//  1  1#   2  2#   3   4  4#   5  5#   6  6#   7
//����
// 25  26  27  28  29  30  31  32  33  34  35  36 
//  1  1#   2  2#   3   4  4#   5  5#   6  6#   7
//ʱ��
// 1/16  1/8 1/4 1/2  1/1
//   1    2   4   8    16

unsigned char Music[]=
{
	13,4,
	13,4,
	20,4,
	20,4,
	22,4,
	22,4,
	20,8,
	18,4,
	18,4,
	17,4,
	17,4,
	15,4,
	15,4,
	13,8,
	0xFF
};

unsigned char FreqSelect,MusicSelect;

void main()
{
	Timer0Init();
	while(1)
	{
		if(Music[MusicSelect]!=0xFF)
		{
		FreqSelect=Music[MusicSelect];
		MusicSelect++;
		Delay(SPEED/4*Music[MusicSelect]);
		MusicSelect++;
		TR0=0;
		Delay(10);
		TR0=1;
		}
		else
		{
			TR0=0;
			while(1);
		}
	}
}

void Timer0_Rountine() interrupt 1 
{	
	if(FreTable[FreqSelect])
	{
		TL0 =FreTable[FreqSelect]%256;		
		TH0 =FreTable[FreqSelect]/256;
		Buzzer=!Buzzer;
	}
}